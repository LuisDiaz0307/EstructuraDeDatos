﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Listas_
{
    class Program
    {
        static void Main(string[] args)
        {
            // List <>

            List<string> lista = new List<string>();
            lista.Add("Super Mario Bros");
            lista.Add("Super Smash Bros");
            lista.Add("Super Mario 64");
            lista.Add("Super Mario sunshine");

            for (int i = 0; i < lista.Count(); i++)
            {
                Console.WriteLine(lista[i]);
            }

            Console.ReadKey();
        }

    }
}

