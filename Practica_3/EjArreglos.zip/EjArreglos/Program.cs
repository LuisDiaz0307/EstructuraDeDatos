﻿using System;
using System.Collections.Generic;

namespace EJEMPLOS
{
    class Ejemplo_Arreglos
    {
        static void Main(string[] args)

            //Codigo para Escribir y almacenar el nombre de Juegos

        {
            double[] numero;
            numero = new double[5];
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Numero " + (i + 1) + " de la lista es :");
                numero[i] = double.Parse(Console.ReadLine());
            }
            Mostrar(numero);
            Console.ReadKey();
        }
        static void Mostrar(double[] numero)
        {
            Console.WriteLine("Los numeros escritos fueron: ");
            for (int i = 0; i < 5; i++)
            {
                Console.Write("\t" + numero[i]);
            }
        }
    }
}